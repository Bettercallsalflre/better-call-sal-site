import React from "react";
import { motion } from "framer-motion";

export default function App() {
  return (
    <div className="font-sans bg-white text-black">
      <section className="bg-gradient-to-r from-pink-400 to-teal-400 text-white p-10 text-center">
        <img
          src="/your-photo.jpg"
          alt="Sal - Real Estate Agent"
          className="rounded-full w-32 h-32 mx-auto border-4 border-white mb-4"
        />
        <h1 className="text-4xl font-bold">Better Call Sal</h1>
        <p className="text-lg mt-2">FL Real Estate Agent - Orlando & Surrounding Areas</p>
      </section>

      <nav className="flex justify-center gap-6 p-4 bg-black text-white">
        <a href="#listings">Listings</a>
        <a href="#reviews">Reviews</a>
        <a href="#about">About Me</a>
        <a href="#events">Local Events</a>
        <a href="#contact">Contact</a>
      </nav>

      <section id="listings" className="p-10 bg-gray-100">
        <h2 className="text-3xl font-bold text-center mb-6">My Listings</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((item) => (
            <div key={item} className="bg-white rounded shadow p-4">
              <img src="/property-placeholder.jpg" alt="Property" className="mb-4 rounded" />
              <h3 className="text-xl font-semibold">Property Title</h3>
              <p>3 Bed • 2 Bath • $350,000</p>
              <button className="mt-2 bg-pink-400 text-white px-4 py-2 rounded">View Details</button>
            </div>
          ))}
        </div>
      </section>

      <section id="reviews" className="p-10">
        <h2 className="text-3xl font-bold text-center mb-6">Client Reviews</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded shadow p-4">
            <p>"Sal was amazing! He helped us find our dream home."</p>
            <p className="text-right">- Happy Client</p>
          </div>
          <div className="bg-white rounded shadow p-4">
            <p>"Professional, responsive, and knowledgeable."</p>
            <p className="text-right">- Another Client</p>
          </div>
        </div>
      </section>

      <section id="about" className="p-10 bg-gray-100">
        <h2 className="text-3xl font-bold text-center mb-6">About Me</h2>
        <p className="max-w-3xl mx-auto text-center">
          I’m Sal, a passionate real estate agent serving Orlando and the surrounding areas. With years of experience and a commitment to delivering top-notch service, I help my clients navigate the market with confidence.
        </p>
      </section>

      <section id="events" className="p-10">
        <h2 className="text-3xl font-bold text-center mb-6">Local Orlando Events</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded shadow p-4">
            <h3 className="text-xl font-semibold">Orlando Food Festival</h3>
            <p>May 15, 2025 - Downtown Orlando</p>
          </div>
          <div className="bg-white rounded shadow p-4">
            <h3 className="text-xl font-semibold">Lake Eola Art Show</h3>
            <p>June 10, 2025 - Lake Eola Park</p>
          </div>
        </div>
      </section>

      <section id="contact" className="p-10 bg-pink-400 text-white text-center">
        <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
        <p>Email: Bettercallsalflre@gmail.com | Phone: (561) 568-8372</p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="https://instagram.com" target="_blank">Instagram</a>
          <a href="https://facebook.com" target="_blank">Facebook</a>
          <a href="https://linkedin.com" target="_blank">LinkedIn</a>
        </div>
      </section>
    </div>
  );
}